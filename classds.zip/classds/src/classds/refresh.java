/*
project name: Class8ds
program:refresh
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: refresh output screen
*/
package classds;
import java.awt.Robot;
public class refresh { 
    public static void clear(Robot rob,int delay){
        rob.keyPress(17);
        rob.keyPress(76);
        rob.keyRelease(17);
        rob.keyRelease(76);
        rob.delay(delay);
    }
}