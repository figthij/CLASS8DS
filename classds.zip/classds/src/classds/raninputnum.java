/*
project name: Classds
program:raninputnum
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
Makes random numbers 
*/
package classds;
import java.util.Random;
public class raninputnum {
    public void raninputnum(int[] value,int i){
        Random rnum = new Random();
        value[i]=rnum.nextInt(1000);
    }
}
