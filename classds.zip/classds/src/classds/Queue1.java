/*
project name: Classds
program:Queue1
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
sets up various queue basics to be used
*/
package classds;
import java.util.LinkedList;
public class Queue1<T> {
    private LinkedList list;
    public Queue1(){
        list=new LinkedList();
    }
    public boolean isEmpty(){
        return(list.size()==0);
    }
    public void enqueue(Object item){
        list.add(item);
    }
    public Object dequeue(){
        Object item=list.get(1);
        list.remove(0);
        return item;
    }
    public Object peek(){
        return list.get(0);
    }
}
