/*
project name: Classds
program:exit
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
displays an exit screen saying goodbye
*/
package classds;

import java.awt.AWTException;
import java.awt.Robot;

public class exit {
    public void exit() throws AWTException{
        Robot rob=new Robot();
        refresh.clear(rob,500);
        String title="exit";
        OutputClass test = new OutputClass();
        test.printScreen(title);
        System.out.println("good bye");
    }
}
