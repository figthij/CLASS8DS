/*
project name: Classds
program:precedence
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
shows which symbol goes first
*/
package classds;
public class precedence {
        public int precedence(char c){
        switch(c){
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }
    public int precedences(String c){
        switch(c){
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "^":
                return 3;
        }
        return -1;
    }

}
