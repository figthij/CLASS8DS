/*
project name: Classds
program:flip
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
flips the queue around
*/
package classds;
import java.util.LinkedList;
import java.util.Queue;
public class flip {
    public Queue<Character> flip(Queue<Character> nums){
        Queue<Character> nums2;
        nums2 = new LinkedList<>();
        String s=" ";
        for(int x= nums.size(); x>0;x--){
            s+=nums.remove();
        }
        char ch;
        for(int x= s.length()-1;x>0;x--){
            ch=s.charAt(x);
            nums2.add(ch);
        }
        return nums2;
    }
    public Queue<String> flips(Queue<String> nums){
        Queue<String> nums2;
        nums2 = new LinkedList<>();
        Queue<String> nums3;
        nums3 = new LinkedList<>();
        String s=" ";
        for(int x= nums.size(); x>0;x--){
            for(int i= nums.size()-1; i>0;i--){
                nums2.add(nums.remove());
                for(int i1=nums2.size()-(nums2.size()+1); i1>0;i1--){
                    nums.add(nums2.remove());
                }
            }
            nums3.add(nums.remove());
            nums=nums2;
        }
        return nums3;
    }

}
