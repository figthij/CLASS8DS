/*
project name: Classds
program:backin
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
puts numbers in the front of the queue
*/
package classds;
import java.util.LinkedList;
import java.util.Queue;
public class backin {
        public Queue<Character> backin(Queue<Character> q,char c){
        Queue<Character> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    public Queue<String> backins(Queue<String> q,String c){
        Queue<String> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    public Queue<Integer> backini(Queue<Integer> q,int c){
        Queue<Integer> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
}
