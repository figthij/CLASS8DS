/*
project name: Class8ds
program:queue
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: makes a parser using queues and converts equations to different formats and evaluates them
*/
package classds;
import java.awt.AWTException;
import java.awt.Robot;
import static java.lang.Character.isDigit;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
public class queue<T> {
    static Queue<Character> backup(String s){
        flip f =new flip();
        Queue<Character> nums;
        nums = new LinkedList<>();
        char ch;
        for(int x= s.length()-1;x>=0;x--){
            ch=s.charAt(x);
            nums.add(ch);
        }
        nums=f.flip(nums);
        return nums;
    }
    static String convert(String expression){
        precedence p = new precedence();
        flip f =new flip();
        String s="";
        char ca=' ';
        int x1=0;
        int x2=0;
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            char c= expression.charAt(i);//c is the char at i coming from left to right
            s="";
            if(p.precedence(c)>0){//when c is +-* / or ^
                stack=f.flip(stack);
                while(stack.isEmpty()==false && p.precedence(stack.peek())>=p.precedence(c)){//when the precedence of the next number is more than the current
                    if(ca=='^'&&p.precedence(stack.peek())==3){
                        stack2=backup(result);
                        result="";
                        for(int x=stack2.size();x>0;x--){
                            result+=stack2.remove();
                        }
                        x1=1;
                    }
                    if(x1==0){
                        ca=stack.remove();
                        result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    }
                    else{
                        ca=expression.charAt(i+1);
                        result +=ca;//if above is the same than it removes c from the stack and puts it in result
                        result +=stack.remove();//if above is the same than it removes c from the stack and puts it in result
                        x1=0;
                        x2=1;
                    }
                    stack=f.flip(stack);
                }
                stack.add(c);
            }
            else{//result has number put at end
                if(x2==0){
                    result+=c;
                }
                else{
                    x2=0;
                }
            }
        }
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
        }
        char ch;//c is the char at i coming from left to right
        for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
            ch=s.charAt(i);
            result+=ch;
        }
        return result;
    }
    static int evaluateq(Queue<Character> Stack2){//pointer
        precedence p = new precedence();
        backin b = new backin();
        flip f =new flip();
        parser par = new parser();
        Queue<Integer> intStack = new LinkedList<>();//
        Queue<String> sintStack = new LinkedList<>();//
        Queue<Integer> intorsymbol = new LinkedList<>();//1for int 2 for symbol
        Queue<Character> symbol = new LinkedList<>();//
        char ch;
        int i =0,operand1,operand2;
        char op;
        Stack2=f.flip(Stack2);
        char op2;
        String fg = "";
        int sss=Stack2.size();
        while(sss>2){//goes until stack2 is empty
            ch = Stack2.poll();
            if(Stack2.isEmpty()==false){
                op=Stack2.poll();
            }
            else{
                op=' ';
            }
            if(Stack2.isEmpty()==false){
                op2=Stack2.poll();
            }            
            else{
                op2=' ';
            }
            Stack2=b.backin(Stack2,op2);
            Stack2=b.backin(Stack2,op);
            if(isDigit(ch)){
                intStack.add(ch-'0');
                intorsymbol.add(1);
            }
            else if((isDigit(op))&&(isDigit(op2))){
                intStack.add(op-'0');
                intStack.add(op2-'0');
                Stack2.poll();
                Stack2.poll();
                sintStack=par.queuetostringq(intStack);
                sintStack=f.flips(sintStack);
                intStack=par.stringtoint(sintStack);
                operand2=intStack.poll();
                operand1=intStack.poll();
                intorsymbol.add(1);
                switch(ch){
                    case '+':
                        intStack.add(operand1+operand2);
                        break;
                    case '-':
                        intStack.add(operand1-operand2);
                        break;
                    case '*':
                        intStack.add(operand1*operand2);
                        break;
                    case '/':
                        if(operand2!=0){
                            intStack.add(operand1/operand2);
                        }
                        else if(operand2==0){
                            intStack.add(0);
                        }
                        break;
                    case '^':
                        intStack.add((int) Math.pow(operand1, operand2));
                }
                sintStack=par.queuetostringq(intStack);
                sintStack=f.flips(sintStack);
                intStack=par.stringtoint(sintStack);
            }
            else{
                fg+=ch;
                symbol.add(ch);
                intorsymbol.add(2);
            }
            sss=Stack2.size();
        }
        while(Stack2.isEmpty()==false){
            ch = Stack2.poll();
            if(isDigit(ch)){
                intStack.add(ch-'0');
                intorsymbol.add(1);
            }
            else{
                fg+=ch;
                symbol.add(ch);
                intorsymbol.add(2);
            }
        }
        Queue<String> str = new LinkedList<>();//
        Queue<String> ssymbol = new LinkedList<>();//
        sintStack=par.queuetostringq(intStack);
        ssymbol=par.charqueuetostringq(symbol);
        int ssy=ssymbol.size();
        while(ssy!=0){
            int ios=0;
            for(int x=intorsymbol.size();x>0;x--){//merges intstack and symbol back into stack2
                ios=intorsymbol.remove();
                if(ios==1){
                    str.add(sintStack.remove());
                }
                else if(ios==2){
                    str.add(ssymbol.remove());
                }
            }
            sss=str.size();
            String det="";//ch
            String opp="";
            String opp2="";
            while(sss>2){//goes until stack2 is empty
                det = str.poll();
                if(str.isEmpty()==false){
                    opp=str.poll();
                }
                else{
                    opp="";
                }
                if(str.isEmpty()==false){
                    opp2=str.poll();
                }            
                else{
                    opp2="";
                }
                str=b.backins(str,opp2);
                str=b.backins(str,opp);
                if(p.precedences(det)==-1){
                    sintStack.add(det);
                    intorsymbol.add(1);
                }
                else if((p.precedences(opp)==-1)&&(p.precedences(opp2)==-1)){
                    sintStack.add(opp);
                    sintStack.add(opp2);
                    str.poll();
                    str.poll();
                    sintStack=f.flips(sintStack);
                    intStack=par.stringtoint(sintStack);
                    operand2=intStack.poll();
                    operand1=intStack.poll();
                    intorsymbol.add(1);
                    switch(det){
                        case "+":
                            intStack.add(operand1+operand2);
                            sintStack=par.queuetostringq(intStack);
                            break;
                        case "-":
                            intStack.add(operand1-operand2);
                            sintStack=par.queuetostringq(intStack);
                            break;
                        case "*":
                            intStack.add(operand1*operand2);
                            sintStack=par.queuetostringq(intStack);
                            break;
                        case "/":
                            if(operand2!=0){
                                intStack.add(operand1/operand2);
                                sintStack=par.queuetostringq(intStack);
                            }
                            else if(operand2==0){
                                intStack.add(0);
                                sintStack=par.queuetostringq(intStack);
                            }
                            break;
                        case "^":
                            intStack.add((int) Math.pow(operand1, operand2));
                            sintStack=par.queuetostringq(intStack);
                    }
                }
                else{
                    fg+=det;
                    ssymbol.add(det);
                    intorsymbol.add(2);
                }
                sss=str.size();
            }
            while(str.isEmpty()==false){
                det = str.poll();
                if(p.precedences(det)==-1){
                    sintStack.add(det);
                    intorsymbol.add(1);
                }
                else{
                    fg+=det;
                    ssymbol.add(det);
                    intorsymbol.add(2);
                }
            }
            ssy=ssymbol.size();
        }
        intStack=par.stringtoint(sintStack);
        return intStack.peek();
    }
    public void main() throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="queue";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(s.matches(exit)==false){
            test.printScreen(title);
            parser p = new parser();
            random r =new random();
            String in = "";
            int top=5;
            int tops=4;
            in=p.inttostr(r.ran(top),r.rans(tops),top,tops);
            String post = convert(in);
            Queue<Character> n=new LinkedList<>();
            n=p.stringtoqueue(post);
            System.out.println("Infix Expression: "+in);
            System.out.println("Postfix Expression: "+post);
            System.out.println("Result is: "+ evaluateq(n));//stackp goes in forward
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to get another combination");
            s=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }
    }
}
