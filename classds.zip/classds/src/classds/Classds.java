/*
project name: Class8ds
program:Class8ds
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
acts as main menu and directs from screen to screen
*/
package classds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;

public class Classds {
    //timer clearing is irritating to look at see if there is a better way to deal with it 
    //check if shortened version of linked list is ok
    //remember to change date on display and headers
    //check that dos is display screen

    //                               1         2         3         4         5         6         7        E           
    //                     01234567890123456789012345678901234567890123456789012345678901234567890123456789
    public static void main(String[] args) throws AWTException {
        refresh re=new refresh();
        intro in= new intro();
        in.intro();
        Scanner sc = new Scanner(System.in);
        String choice;
        int i=0;
        OutputClass test = new OutputClass();
        while(i!=1){
        String title="main menu";
        test.printScreen(title);
        System.out.println("Which option do you want to choose:");
        System.out.println("TIMER");
        System.out.println("RAND3");
        System.out.println("STACK");
        System.out.println("QUEUE");
        System.out.println("LIST");
        System.out.println("Type exactly all in caps or exit by typing EXIT");
        choice=sc.next();
        Robot rob=new Robot();
        refresh.clear(rob,500);
        switch(choice){
            case "TIMER":
            {
                timer time= new timer();
                break;
            }
            case "RAND3":
            {
                rand3 ran =new rand3();
                break;
            }
            case "STACK":
            {
                stack stak=new stack();
                stak.main();
                break;
            }
            case "QUEUE":
            {
                queue q = new queue();
                q.main();
                break;
            }
            case "LIST":
            {
                linkedlist ll=new linkedlist();
                ll.main();
                break;
            }
            case "EXIT":
            {
                i=1;
                break;
            }
            default:
            {
                System.out.println("try another choice");
                break;
            }
            }
        }
        exit ex=new exit();
        ex.exit();
    }
}
    

