/*
project name: Classds
program:largest
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
Finds the largest number
*/
package classds;
public class largest {
    public int largestinlist(int[] value, int size){
        int large=0;
        for(int i=0;i<size;i++){
            if(value[i]>large){
                large=value[i];
            }
        }
        return large;
    }
}
