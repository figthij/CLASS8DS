/*
project name: Class8ds
program:stack
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: makes a parser using stacks and converts equations to different formats and evaluates them
*/
package classds;
import java.awt.AWTException;
import java.awt.Robot;
import static java.lang.Character.isDigit;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;
public class stack {
    static int precedence(char c){
        switch(c){
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }    
    static String convert(String expression){
        String result ="";
        Stack<Character> stack = new Stack<>();
        for(int i =0; i<expression.length();i++){
            char c= expression.charAt(i);
            if(precedence(c)>0){
                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)){
                    result +=stack.pop();
                }
                stack.push(c);
            }
            else if(c==')'){
                char x = stack.pop();
                while(x!='('){
                    result += x;
                    x=stack.pop();
                }
            }
            else if(c=='('){
                stack.push(c);
            }
            else{
                result+=c;
            }
        }
        for(int i = 0; i<=stack.size();i++){
            result +=stack.pop();
        }
        return result;
    }
    Stack<Integer> intStack = new Stack<>();
    int top_int=-1;
    public void push_int(int item){
        intStack.push((Integer) item);
    }
    char pop_int(){
        Integer a=intStack.pop();
        return 0;//may need to delete
    }
    static int evaluate(Stack<Character> postfix){//pointer
        int top_int=-1;
        Stack<Integer> intStack = new Stack<>();//
        Stack<Character> Stack2 = new Stack<>();//
        char ch= postfix.peek();
        int i =0,operand1,operand2;
        char op;
        while(postfix.empty()==false){//only stops when ppostfix is empty
            ch = postfix.pop();
            if(isDigit(ch)){//puts ch into stackk2 and leaves it at that
                Stack2.push(ch);
            }
            else{//when ch is a symbol op is set to be the number before it
                op=postfix.peek();
                Stack2.push(ch);
            }
        }
        while(Stack2.empty()==false){//goes until stack2 is empty
            ch = Stack2.pop();
            if(isDigit(ch)){
                intStack.push(ch-'0');
            }
            else{
                operand2=intStack.pop();
                operand1=intStack.pop();
                switch(ch){
                    case '+':
                        intStack.push(operand1+operand2);
                        break;
                    case '-':
                        intStack.push(operand1-operand2);
                        break;
                    case '*':
                        intStack.push(operand1*operand2);
                        break;
                    case '/':
                        if(operand2!=0){
                            intStack.push(operand1/operand2);
                        }
                        else if(operand2==0){
                            intStack.push(0);
                        }
                        break;
                    case '^':
                        intStack.push((int) Math.pow(operand1, operand2));
                }
            }
        }
        return intStack.peek();
    }
    static Stack<Character> stringtostack(String expression){
        Stack<Character> stack = new Stack<>();
        for(int i =0; i<expression.length();i++){
            char c= expression.charAt(i);
            stack.push(c);
        }
        return stack;
    }
    static Stack<Integer> ran(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Stack<Integer> st = new Stack<>();
        number=num.nextInt(10);
        st.push(number);
        for(int i=2;i<top;i++){
            number=num.nextInt(10);
            st.push(number);
        }
        number=num.nextInt(10);
        st.push(number);
        return st;
    }
    static Stack<Integer> rans(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Stack<Integer> st = new Stack<>();
        number=num.nextInt(5);//put at 6 instead of 7 to close parenthesis
        st.push(number);
        for(int i=2;i<top;i++){
            number=num.nextInt(5);
            st.push(number);
        }
        number=num.nextInt(5);
        st.push(number);
        return st;
    }
    static String inttostr(Stack<Integer> st,Stack<Integer> st2,int top,int tops){//needs to have one more number than symbol
        Stack<Character> stack = new Stack<>();
        String s="";
        int t=top+tops;
        int n=0;
        int x=0;
        for(int i = 0; i<t;i++){
            if((i%2)==0){//checks if i is even when it is put a number
                x=st.pop();
                switch(x){
                    case 0:
                        s=s+"0";
                        break;
                    case 1:
                        s=s+"1";
                        break;
                    case 2:
                        s=s+"2";
                        break;
                    case 3:
                        s=s+"3";
                        break;
                    case 4:
                        s=s+"4";
                        break;
                    case 5:
                        s=s+"5";
                        break;
                    case 6:
                        s=s+"6";
                        break;
                    case 7:
                        s=s+"7";
                        break;
                    case 8:
                        s=s+"8";
                        break;
                    case 9:
                        s=s+"9";
                        break;
                }
            }
            else if((i%2)!=0){
                x=st2.pop();
                switch(x){
                    case 0:
                        s=s+"+";
                        break;
                    case 1:
                        s=s+"-";
                        break;
                    case 2:
                        s=s+"*";
                        break;
                    case 3:
                        s=s+"/";
                        break;
                    case 4:
                        s=s+"^";
                        break;
                    case 5:
                        if(n==0){
                            s=s+"(";
                            n=1;
                        }
                        else if(n==1){
                            s=s+")";
                            n=0;
                        }
                        break;
                }
            }
        }
        if(n==1)
            s=s+")";
        return s;
    }
    public void main() throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="stack";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(s.matches(exit)==false){
            test.printScreen(title);
            String in = "";
            int top=10;
            int tops=9;
            in=inttostr(ran(top),rans(tops),top,tops);
            String post=convert(in);
            Stack<Character> stackp = new Stack<>();
            stackp=stringtostack(post);
            System.out.println("Infix Expression: "+in);
            System.out.println("Postfix Expression: "+post);
            System.out.println("Result is: "+ evaluate(stackp));//stackp goes in forward
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to get another combination");
            s=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }
    }
}
        