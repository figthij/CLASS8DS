/*
project name: Classds
program:
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
makes header for each screen
*/
package classds;
public class OutputClass {
     //                            1         2         3         4         5         6         7        E           
     //                  01234567890123456789012345678901234567890123456789012345678901234567890123456789
     //TwoNumbers gcdVars = new TwoNumbers();
     public void printScreen(String title){//will have to put in Title to replace and date
     String blankLine = "                                                                                ";
     String headLines = "Date: Nov 4, 2020                                             Author:Erik Bailey";
     System.out.println(headLines);
     String headClass = "CIS210 Data Structures and algorithms";//                                    Eculids";
         int size = headClass.length();
         int titlesize=title.length();
         int clas = 36;
         int pos = 79 - titlesize;
         headClass = headClass +blankLine.substring(clas , pos) + title;//headClass;
         System.out.println(headClass);
     }
     




}
